<?php // Copy this file to your template. Any changes will be overwritten when you update the plugin. ?>
<p>Categories Widget Template. 
<br/>
Provided by the ACF Widgets Plugin.</p>